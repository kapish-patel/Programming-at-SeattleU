class EmotionRecorderEvent{
  String emoji;
  String emotionName;
  DateTime dateTime;

  EmotionRecorderEvent(this.emoji, this.emotionName, this.dateTime);
}