class WorkoutRecorderEvent {
  String emoji;
  String workoutName;
  int hours;
  int minuites;
  DateTime dateTime;

  WorkoutRecorderEvent(this.emoji, this.workoutName, this.hours, this.minuites, this.dateTime);
}

