import './Quiz_header.css'

function Quiz_header(){
    return(
        <div className="Quiz_header_container">
            <h1>Selector - Quiz</h1>
        </div>
    )
}

export default Quiz_header