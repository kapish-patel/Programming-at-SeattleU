class DietRecorderEvent {
  String mealname;
  int quantity;
  int calories;
  DateTime dateTime;

  DietRecorderEvent(this.mealname, this.quantity, this.calories, this.dateTime);
}